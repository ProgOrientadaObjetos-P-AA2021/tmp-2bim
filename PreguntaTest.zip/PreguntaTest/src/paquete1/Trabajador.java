/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete1;

/**
 *
 * @author reroes
 */
public class Trabajador {

    private String nombres;
    private double sueldo;
    private double diasTrabajados;
    private double costoDiaTrabajado;
    
    /*El sueldo es igual a la multiplicación de días trabajados por 
    costo día trabajado*/
    
    
    
}
