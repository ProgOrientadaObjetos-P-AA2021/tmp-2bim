/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete1;

import java.lang.reflect.Field;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
/**
 *
 * @author reroes
 */
public class TrabajadorTest {
    
    private Trabajador instance;
    
    public TrabajadorTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
        instance = new Trabajador();
    }

    @After
    public void tearDown() throws Exception {
    }
    
    
   
    @Test
    public void testEstablecerNombres() throws 
            NoSuchFieldException, IllegalArgumentException, 
            IllegalAccessException {
        System.out.println("establecerNombres");
        String n = "Luis Mario";
        instance.establecerNombres(n);
        Field field = instance.getClass().getDeclaredField("nombres");
        field.setAccessible(true);
        assertEquals("LUIS MARIO", field.get(instance));
    }

    
    
    @Test
    public void testEstablecerSueldo()  throws 
            NoSuchFieldException, IllegalArgumentException, 
            IllegalAccessException {
        System.out.println("establecerSueldo");
        
        instance.establecerDiasTrabajados(10);
        instance.establecerCostoDiaTrabajado(100);
        instance.establecerSueldo();
        Field field = instance.getClass().getDeclaredField("sueldo");
        field.setAccessible(true);
        assertEquals(1000.0, field.get(instance));
    }

    
    @Test
    public void testEstablecerDiasTrabajados() throws 
            NoSuchFieldException, IllegalArgumentException, 
            IllegalAccessException  {
        System.out.println("establecerDiasTrabajados");
        double n = 2.0;
        instance.establecerDiasTrabajados(n);
        Field field = instance.getClass().getDeclaredField("diasTrabajados");
        field.setAccessible(true);
        assertEquals(2.0, field.get(instance));
    }

    
    @Test
    public void testEstablecerCostoDiaTrabajado()  throws 
            NoSuchFieldException, IllegalArgumentException, 
            IllegalAccessException {
        System.out.println("establecerCostoDiaTrabajado");
        double n = 100.0;
        instance.establecerCostoDiaTrabajado(n);
        Field field = instance.getClass().getDeclaredField("costoDiaTrabajado");
        field.setAccessible(true);
        assertEquals(100.0, field.get(instance));
    }

    
    @Test
    public void testObtenerNombres() {
        System.out.println("obtenerNombres");
        
        String expResult = "LUCIA";
        instance.establecerNombres("Lucia");
        String result = instance.obtenerNombres();
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testObtenerSueldo() {
        System.out.println("obtenerSueldo");
        
        double expResult = 1000.0;
        instance.establecerDiasTrabajados(10);
        instance.establecerCostoDiaTrabajado(100);
        instance.establecerSueldo();
        double result = instance.obtenerSueldo();
        assertEquals(expResult, result, 0.0);
        
    }

    
    @Test
    public void testObtenerDiasTrabajados() {
        System.out.println("obtenerDiasTrabajados");
        
        double expResult = 5.0;
        instance.establecerDiasTrabajados(5);
                
        double result = instance.obtenerDiasTrabajados();
        assertEquals(expResult, result, 0.0);
        
    }

    
    @Test
    public void testObtenerCostoDiaTrabajado() {
        System.out.println("obtenerCostoDiaTrabajado");
        
        double expResult = 10.2;
        instance.establecerCostoDiaTrabajado(10.2);
        double result = instance.obtenerCostoDiaTrabajado();
        assertEquals(expResult, result, 0.0);
        
    }
    
    @Test
    public void testToString() {
        System.out.println("toString");
        
        String expResult = "Trabajador con nombres: LUCIA\nSueldo: 20,0";
        instance.establecerNombres("Lucia");
        instance.establecerDiasTrabajados(1);
        instance.establecerCostoDiaTrabajado(20.0);
        instance.establecerSueldo();
        String result = instance.toString();
        assertEquals(expResult, result);
        
    }
    
}
